# Trip Planner Minimal Admin (Next.js + Prisma + SQLite)

## Quick start (local)
```bash
npm i
npx prisma migrate dev --name init
npm run dev
```
Open http://localhost:3000/admin/places and http://localhost:3000/admin/days

## Deploy notes
- For production (e.g., Vercel), use a hosted database (Neon/Turso/PlanetScale). Update `prisma/schema.prisma` datasource URL.
- Then run `prisma migrate deploy` as part of your deploy pipeline.

## What you get
- CRUD for **Places** with types: HOTEL / TRANSPORT / ATTRACTION / OTHER
- CRUD for **Days** with an **optional Global Attraction** (requirement #4)
- No SQL functions—uses Prisma to avoid the Postgres PL/pgSQL loop error you saw.
