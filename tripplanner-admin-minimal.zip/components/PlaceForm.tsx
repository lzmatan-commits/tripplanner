'use client'

import { useState, useEffect } from 'react'

type Place = {
  id?: number
  name: string
  type: 'HOTEL' | 'TRANSPORT' | 'ATTRACTION' | 'OTHER'
  address?: string
  city?: string
  country?: string
  lat?: number
  lng?: number
  notes?: string
}

export default function PlaceForm() {
  const [places, setPlaces] = useState<Place[]>([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState<Place>({
    name: '',
    type: 'ATTRACTION',
    address: '',
    city: '',
    country: '',
    lat: undefined,
    lng: undefined,
    notes: '',
  })

  async function refresh() {
    setLoading(true)
    const res = await fetch('/api/places')
    const data = await res.json()
    setPlaces(data)
    setLoading(false)
  }

  useEffect(() => { refresh() }, [])

  async function save() {
    const body = { ...form }
    const res = await fetch('/api/places', { method: 'POST', body: JSON.stringify(body) })
    if (res.ok) {
      setForm({ name: '', type: 'ATTRACTION', address: '', city: '', country: '', lat: undefined, lng: undefined, notes: '' })
      await refresh()
    } else {
      alert('Failed to save')
    }
  }

  async function remove(id: number) {
    if (!confirm('Delete item?')) return
    const res = await fetch(`/api/places/${id}`, { method: 'DELETE' })
    if (res.ok) await refresh()
  }

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <div style={{ display: 'grid', gap: 8, border: '1px solid #ddd', borderRadius: 12, padding: 16 }}>
        <h3 style={{ margin: 0 }}>Create Place</h3>
        <input placeholder="Name" value={form.name} onChange={e=>setForm(f=>({...f, name:e.target.value}))} />
        <select value={form.type} onChange={e=>setForm(f=>({...f, type:e.target.value as Place['type']}))}>
          <option value="HOTEL">Hotel</option>
          <option value="TRANSPORT">Transport</option>
          <option value="ATTRACTION">Attraction</option>
          <option value="OTHER">Other</option>
        </select>
        <input placeholder="Address" value={form.address||''} onChange={e=>setForm(f=>({...f, address:e.target.value}))} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <input placeholder="City" value={form.city||''} onChange={e=>setForm(f=>({...f, city:e.target.value}))} />
          <input placeholder="Country" value={form.country||''} onChange={e=>setForm(f=>({...f, country:e.target.value}))} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <input placeholder="Lat" value={form.lat ?? ''} onChange={e=>setForm(f=>({...f, lat: e.target.value? Number(e.target.value): undefined}))} />
          <input placeholder="Lng" value={form.lng ?? ''} onChange={e=>setForm(f=>({...f, lng: e.target.value? Number(e.target.value): undefined}))} />
        </div>
        <textarea placeholder="Notes" value={form.notes||''} onChange={e=>setForm(f=>({...f, notes:e.target.value}))} />
        <button onClick={save}>Save</button>
      </div>

      <div style={{ border: '1px solid #ddd', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Places</h3>
        {loading ? <p>Loading…</p> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th align="left">ID</th>
                <th align="left">Name</th>
                <th align="left">Type</th>
                <th align="left">City</th>
                <th align="left">Country</th>
                <th align="left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {places.map(p => (
                <tr key={p.id} style={{ borderTop: '1px solid #eee' }}>
                  <td>{p.id}</td>
                  <td>{p.name}</td>
                  <td>{p.type}</td>
                  <td>{p.city}</td>
                  <td>{p.country}</td>
                  <td>
                    <button onClick={()=>remove(p.id!)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
