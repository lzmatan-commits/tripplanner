'use client'

import { useEffect, useMemo, useState } from 'react'

type Place = {
  id: number
  name: string
  type: 'HOTEL' | 'TRANSPORT' | 'ATTRACTION' | 'OTHER'
}

type Day = {
  id?: number
  date: string
  title?: string
  globalAttractionId?: number | null
  notes?: string
}

export default function DayForm() {
  const [days, setDays] = useState<any[]>([])
  const [places, setPlaces] = useState<Place[]>([])
  const [form, setForm] = useState<Day>({
    date: new Date().toISOString().slice(0,10),
    title: '',
    globalAttractionId: null,
    notes: ''
  })
  const [loading, setLoading] = useState(true)

  async function refresh() {
    setLoading(true)
    const [dRes, pRes] = await Promise.all([
      fetch('/api/days'),
      fetch('/api/places')
    ])
    setDays(await dRes.json())
    setPlaces(await pRes.json())
    setLoading(False)
  }

  useEffect(() => { refresh() }, [])

  async function save() {
    const body = {
      ...form,
      date: new Date(form.date).toISOString(),
    }
    const res = await fetch('/api/days', { method: 'POST', body: JSON.stringify(body) })
    if (res.ok) {
      setForm({ date: new Date().toISOString().slice(0,10), title: '', globalAttractionId: null, notes: '' })
      await refresh()
    } else {
      alert('Failed to save day')
    }
  }

  async function remove(id: number) {
    if (!confirm('Delete day?')) return
    const res = await fetch(`/api/days/${id}`, { method: 'DELETE' })
    if (res.ok) await refresh()
  }

  const attractions = useMemo(() => places.filter(p => p.type === 'ATTRACTION'), [places])

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <div style={{ display: 'grid', gap: 8, border: '1px solid #ddd', borderRadius: 12, padding: 16 }}>
        <h3 style={{ margin: 0 }}>Create Day</h3>
        <input type="date" value={form.date} onChange={e=>setForm(f=>({...f, date:e.target.value}))} />
        <input placeholder="Title (optional)" value={form.title||''} onChange={e=>setForm(f=>({...f, title:e.target.value}))} />
        <select
          value={form.globalAttractionId ?? ''}
          onChange={e=>setForm(f=>({...f, globalAttractionId: e.target.value ? Number(e.target.value) : null}))}
        >
          <option value="">(Optional) Global Attraction for the Day</option>
          {attractions.map(a => (
            <option key={a.id} value={a.id}>{a.name}</option>
          ))}
        </select>
        <textarea placeholder="Notes" value={form.notes||''} onChange={e=>setForm(f=>({...f, notes:e.target.value}))} />
        <button onClick={save}>Save</button>
      </div>

      <div style={{ border: '1px solid #ddd', borderRadius: 12, padding: 16 }}>
        <h3 style={{ marginTop: 0 }}>Days</h3>
        {loading ? <p>Loading…</p> : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th align="left">Date</th>
                <th align="left">Title</th>
                <th align="left">Global Attraction</th>
                <th align="left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {days.map(d => (
                <tr key={d.id} style={{ borderTop: '1px solid #eee' }}>
                  <td>{new Date(d.date).toISOString().slice(0,10)}</td>
                  <td>{d.title || ''}</td>
                  <td>{d.globalAttraction?.name || ''}</td>
                  <td><button onClick={()=>remove(d.id)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
