import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Trip Planner Admin',
  description: 'Minimal admin to manage places and itinerary days',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Helvetica, Arial' }}>
        <div style={{ maxWidth: 1000, margin: '0 auto', padding: 16 }}>
          <header style={{ display: 'flex', gap: 16, alignItems: 'center', justifyContent: 'space-between' }}>
            <h1 style={{ fontSize: 24, fontWeight: 700 }}>Trip Planner Admin</h1>
            <nav style={{ display: 'flex', gap: 12 }}>
              <a href="/admin/places">Places</a>
              <a href="/admin/days">Days</a>
            </nav>
          </header>
          <main style={{ marginTop: 24 }}>{children}</main>
        </div>
      </body>
    </html>
  )
}
