import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const places = await prisma.place.findMany({ orderBy: { id: 'desc' } })
  return NextResponse.json(places)
}

export async function POST(req: Request) {
  const data = await req.json()
  const place = await prisma.place.create({ data })
  return NextResponse.json(place, { status: 201 })
}
