import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

type Params = { params: { id: string } }

export async function GET(_: Request, { params }: Params) {
  const id = Number(params.id)
  const place = await prisma.place.findUnique({ where: { id } })
  if (!place) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(place)
}

export async function PUT(req: Request, { params }: Params) {
  const id = Number(params.id)
  const data = await req.json()
  const place = await prisma.place.update({ where: { id }, data })
  return NextResponse.json(place)
}

export async function DELETE(_: Request, { params }: Params) {
  const id = Number(params.id)
  await prisma.place.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
