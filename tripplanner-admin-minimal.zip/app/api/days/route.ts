import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const days = await prisma.day.findMany({
    orderBy: { date: 'asc' },
    include: { globalAttraction: true },
  })
  return NextResponse.json(days)
}

export async function POST(req: Request) {
  const data = await req.json()
  // date should be ISO string
  if (data.date) data.date = new Date(data.date)
  const day = await prisma.day.create({ data })
  return NextResponse.json(day, { status: 201 })
}
