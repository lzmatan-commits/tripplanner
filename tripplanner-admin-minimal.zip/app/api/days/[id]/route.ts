import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

type Params = { params: { id: string } }

export async function GET(_: Request, { params }: Params) {
  const id = Number(params.id)
  const day = await prisma.day.findUnique({
    where: { id },
    include: { globalAttraction: true },
  })
  if (!day) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(day)
}

export async function PUT(req: Request, { params }: Params) {
  const id = Number(params.id)
  const data = await req.json()
  if (data.date) data.date = new Date(data.date)
  const day = await prisma.day.update({ where: { id }, data })
  return NextResponse.json(day)
}

export async function DELETE(_: Request, { params }: Params) {
  const id = Number(params.id)
  await prisma.day.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
