export default function Home() {
  return (
    <div>
      <h2>Welcome</h2>
      <p>Use the navigation to manage Places and Days.</p>
    </div>
  )
}
