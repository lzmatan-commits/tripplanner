import PlaceForm from '@/components/PlaceForm'

export const dynamic = 'force-dynamic'

export default function AdminPlacesPage() {
  return (
    <div>
      <h3 style={{ marginTop: 0 }}>Manage Places (Hotels / Transport / Attractions)</h3>
      <PlaceForm />
    </div>
  )
}
