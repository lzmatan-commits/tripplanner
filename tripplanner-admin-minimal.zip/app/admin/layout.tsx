export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 16 }}>Admin</h2>
      {children}
    </div>
  )
}
