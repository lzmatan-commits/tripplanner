import DayForm from '@/components/DayForm'

export const dynamic = 'force-dynamic'

export default function AdminDaysPage() {
  return (
    <div>
      <h3 style={{ marginTop: 0 }}>Manage Days (with optional global attraction)</h3>
      <DayForm />
    </div>
  )
}
