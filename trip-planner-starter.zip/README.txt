Trip Planner Starter

This placeholder file ensures the directory is zipped correctly.